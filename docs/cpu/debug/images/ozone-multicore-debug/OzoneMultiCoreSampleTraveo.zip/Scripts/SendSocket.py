#!/usr/bin/env python3
import argparse
import socket
import sys
import time


def main():
    parser = argparse.ArgumentParser(description="Socket I/F: sends a command string to an Ozone instance on localhost and prints the response.")
    parser.add_argument("--port", type=int, required=True, help="TCP port on localhost")
    parser.add_argument("--cmd", type=str, required=True, help='Command to send (pass with quotes, e.g. --cmd "?")')
    parser.add_argument("--timeout", type=int, default=1000, help="Duration to wait for the response [ms] (default: 1000)")
    args = parser.parse_args()

    host = "127.0.0.1"

    data = args.cmd
    # optional newline framing (common for simple servers); remove if your server expects raw bytes only
    if not data.endswith("\n"):
        data_to_send = (data + "\n").encode("utf-8")
    else:
        data_to_send = data.encode("utf-8")

    timeout_s = args.timeout / 1000

    with socket.create_connection((host, args.port), timeout=timeout_s) as sock:
        sock.sendall(data_to_send)
        sock.settimeout(timeout_s)
        chunks = []
        while True:
            try:
                buf = sock.recv(4096)
            except socket.timeout:
                break
            if not buf:
                break
            chunks.append(buf)

    out = b"".join(chunks).decode("utf-8", errors="replace")
    print(out, end="")

if __name__ == "__main__":
    main()
    