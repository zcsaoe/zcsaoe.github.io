# Traveo II Multicore Hello World Application

This folder contains a simple multicore Traveo II application tested on the **CYTVII-B-H-8M-176-CPU Rev. 3** board with the **CYT4BF8CDDES** MCU.

## Overview

The application demonstrates running simple Hello World projects on three cores:

* CM0+
* CM7_0
* CM7_1

All projects use **semihosting** for `printf` output.

All folders contain an Embedded Studio project as well as Ozone debug projects. Both can be used for multicore debugging. In addition, Oozne projects are provided, that use automation and scripting capabilities of Ozone to demonstrate reducing the complexity of the debug setup exposed to the end user and implementing host based core synchronization features.

## Folder Description

### J-LinkScriptFile

Contains J-Link script files modified for multicore debugging.

### CYT4BF8CDD_M0_RAM

Application linked in RAM for the secondary core **CM0+**.

Memory layout:

```text
RAM_M7_0 RWX 0x28003000 0x00002000
```

### CYT4BF8CDD_M7_0_Flash

Application linked in flash for the main core **CM7_0**.

Memory layout:

```text
FLASH_M7_0 RX  0x10030000 0x00008000
RAM_M7_0   RWX 0x28001000 0x00001000
```

### CYT4BF8CDD_M7_1_Flash

Application linked in flash for the main core **CM7_1**.

Memory layout:

```text
FLASH_M7_1 RX  0x10038000 0x00008000
RAM_M7_1   RWX 0x28002000 0x00001000
```

### Scripts

A script written in Python3 that is capable of sending and receiving character strings via a socket interface. The script is used for allowing multiple Ozone instances to communicate. For further information please invoke the script on the command line with the parameter `-h` or `--help`.

## Single Core Debugging

1. First, connect to one or both of the main **CM7** cores. If required, the **CM0+** core is enabled implicit by J-Link.
2. Start the debug session for **CM0+**.

## Multi Core debugging

For multicore debugging, 2 sample projects are provided. Both show multicore debugging with one Ozone instance per core, one being the main instance doing the initialization and tasks required to enable debugging on the sub core, and the other being the sub instance. In this sample the **CM7_0** is the main core and the **CM7_1** is the sub core. The main Ozone instance (for **CM7_0**) will download all memory contents, i.e. the applications for both **CM7_0** and **CM7_1**. The sub Ozone instance will not perform a download of the application.

The projects also provide a sample implementation of host based core synchronization features. 

The main difference between both projects lies in the way the main Ozone instance launches the sub instance.

### Manual Launching the Sub Instance

1. Open an Ozone instance and load `Main.jdebug`.
2. Start a debug session by clicking onto the green "power" button.
3. Click onto the button "Launch Ozone for Sub" in the custom tool bar. 
4. A new Ozone instance is started. Align both instances on screen so they can be seen simultaneously.
5. In the main instance click onto the "Run All" button in the custom tool bar.
6. Firmware execution resumes on both cores. Please note the changing output in the terminal window on both instances.
7. In the main instance click onto the "Break All" button in the custom tool bar.
8. Firmware execution stops on both cores.
9. In the main instance click onto the "Run Sub" button in the custom tool bar.
10. Firmware execution resumes on the sub core only.
11. In the main instance click onto the "Break Sub" button in the custom tool bar.
12. Firmware execution stops on the sub core.
13. In the main instance click onto the "Exit Sub" button in the custom tool bar.
14. The debug session on the sub instance is ended and the sub instance is closed.
15. Close the main instance.

### Automatic Launching the Sub Instance

1. Open an Ozone instance and load `Main_Auto.jdebug`.
2. Start a debug session by clicking onto the green "power" button.
3. A new Ozone instance is started. Align both instances on screen so they can be seen simultaneously.
4. In the main instance click onto the "Run All" button in the custom tool bar.
5. Firmware execution resumes on both cores. Please note the changing output in the terminal window on both instances.
6. In the main instance click onto the "Break All" button in the custom tool bar.
7. Firmware execution stops on both cores.
8. In the main instance click onto the "Run Sub" button in the custom tool bar.
9. Firmware execution resumes on the sub core only.
10. In the main instance click onto the "Break Sub" button in the custom tool bar.
11. Firmware execution stops on the sub core.
12. In the main instance click onto the "Exit Sub" button in the custom tool bar.
13. The debug session on the sub instance is ended and the sub instance is closed.
14. Close the main instance.

## Notes

* All applications are simple Hello World projects.
* `printf` output is routed through semihosting.
* The RAM and flash regions are configured to avoid overlap between the individual core applications.
* Flash download is only supported through the main **CM7** cores.
* No reset is performed in any scenario.
* A custom reset sequence can be implemented if required.
* For further details please refer to the KB article: https://kb.segger.com/Multicore_Debugging_with_Ozone
